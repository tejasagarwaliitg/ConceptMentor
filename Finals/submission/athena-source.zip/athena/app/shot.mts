import { chromium } from "playwright";
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1200, height: 900 } });
const errs: string[] = []; p.on("pageerror", e => errs.push(e.message));
await p.goto("http://127.0.0.1:3000/", { waitUntil: "domcontentloaded" }); await p.waitForTimeout(2500);
if (await p.getByRole("button", { name: "Continue as guest" }).count()) { await p.getByRole("button", { name: "Continue as guest" }).click(); await p.waitForTimeout(2500); }
await p.getByRole("navigation").getByRole("button", { name: "Practice" }).click(); await p.waitForTimeout(1200);
await p.selectOption("#pr-node", "projectile");
await p.getByRole("radio", { name: /Level B/ }).click(); await p.waitForTimeout(600);
const cards = await p.locator(".level-card i").allInnerTexts();
console.log("availability:", cards.join(" | "));
// click through up to 4 questions to see all kinds
for (let i = 0; i < 4; i++) {
  await p.getByRole("button", { name: /Start practice|Next fresh question/ }).click().catch(() => {});
  await p.waitForTimeout(1500);
  const stem = await p.locator(".question-stem").innerText().catch(() => null);
  if (!stem) { console.log("no question:", (await p.locator(".unavailable-card h1").innerText().catch(()=>"?"))); break; }
  const numeric = await p.locator(".numeric-input").count() > 0;
  console.log(`q${i}: ${numeric ? "numeric" : "mcq"} | ${stem.slice(0, 55)}`);
  if (numeric) {
    await p.locator(".numeric-input").fill("40");
    await p.getByRole("button", { name: "Check answer" }).click();
  } else {
    await p.locator(".answer-option").first().click();
    const multi = (await p.locator(".question-concept").innerText()).includes("one or more correct");
    if (multi) await p.locator(".answer-option").nth(2).click();
    await p.getByRole("button", { name: "Check answer" }).click();
  }
  await p.waitForTimeout(1200);
  console.log("   ->", await p.locator(".practice-result b").innerText(), "| answer:", (await p.locator(".practice-result p").first().innerText()).slice(0, 60));
}
await p.screenshot({ path: "/tmp/q/ui-final.png" });
console.log("errors:", errs.length, errs.slice(0, 2));
await b.close();
